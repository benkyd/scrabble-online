// fixes dictionary files, removes short words and capitalises them all


